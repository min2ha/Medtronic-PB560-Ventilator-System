
How to verify your Md5 Signature: 

1- Open the exe file "Md5Sum.exe".
3- Choose the action "Generate Checksums".
2- Drag the file to be tested in the main windows of the software- 
   The checksum value is instantly calculated and shown in the box.
4- Compare this value with the value contain in the reference file "name.md5"- 
   If the values are egual, the file is correct else not.



These files are licensed under the GPL. Please see http://www.gnu.org/licenses/gpl.html for license details.